Predicting:

java -jar PromFind.jar -set test.txt -out out.txt -sl 251 -mode 0 -md 1000 -dt1 0.5 -dt2 0.5 -step 1

Mandatory:  
-set: input file 
-out: output file 
-sl: sliding window size 

Optional:
-mode: 0 is for 1 model, 1 is for 2 models, 3 is for 2 models with TATA-box matrix. Default is 0.
-md: minimum distance between promoters, default is 1000
-dt1: decision threshold for model_1, default is 0.5 
-dt2: decision threshold for model_2(TATA+), default is 0.5
-step: stride of the sliding window, default is 1

More Examples:
java -jar PromFind.jar -set test.txt -out out.txt -sl 251 -mode 2 -md 1000 -dt1 0.5 -dt2 0.9 -step 1
	2 Models, window length 251, TATA+ has high threshold 0.9 plus TATA-box matrix is used to avoid false positives.

java -jar PromFind.jar -set test.txt -out out.txt -sl 1500 -mode 0 -md 1000 -dt1 0.3 -dt2 0.5 -step 1
	1 Model, window length 1500, low threshold value to get high sensitivity.

java -jar PromFind.jar -set test.txt -out out.txt -sl 750 -mode 1 -md 1000 -dt1 0.5 -dt2 0.5 -step 1
	2 Models, window length 750, both models are applied to input without using TATA-box matrix.


Drawing scoring landscapes:

java -jar draw.jar -setp forDraw/model_1.res -out temp/pics

-setp: predictions from PromFind.jar (located in folder forDraw)
-out: output directory
-w: width of one landscape
-h: height of one landscape
-count: number of graphs per picture 
-maxf: maximum number of generated files (default 5000) 














python ../pipeline/predictor2.py model_H_T_NT nts 251 1 predicted_nts.txt
java -jar ../pipeline/draw.jar -setp predicted_nts.txt -out pics_nts -count 12 -step 1 -maxf 10